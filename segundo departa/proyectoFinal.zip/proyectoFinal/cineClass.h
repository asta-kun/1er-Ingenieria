class Cine{
	
		
	public:
		
		char* names[10];//nombres
		char* description[10]; // sinopsis
		int chairs[10];// asientos 30
	   //sets
	   
	   Cine();
		

		
};
