#include <iostream>
#include "cineClass.h"

Cine::Cine(){}




