class Wallet{
	private: 
	    //prototype de metodo
	    
	    int wallet_total;

	
	public: //publics
		Wallet();
		//sets
		void setTotal(int);
		void setGasto(int);

		
		
		//gets
		int getTotal();

			
		
};
