class Biblioteca{
	private:
		
	public:	
		char* libros[10];
		
		int existencias[10];
	   
	   Biblioteca();
		

		
};
